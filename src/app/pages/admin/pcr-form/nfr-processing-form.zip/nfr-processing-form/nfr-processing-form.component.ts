import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nfr-processing-form',
  templateUrl: './nfr-processing-form.component.html',
  styleUrls: ['./nfr-processing-form.component.scss']
})
export class NFRProcessingFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  TabVal: Number = 1;
  TabClickMethod(TabNo: Number): void {
    switch (this.TabVal) {
      case 1:
        //alert('this tab '+this.TabVal);
        this.FormButton1(false); //property form
        break;

      case 2:
        this.ViolationSubmit(false);
        break;

      case 3:
        this.SecuringSubmit(false);
        break;

      case 4:
        this.SubmitWinterization(false);
        break;

      case 5:
        this.YardMaintananceSubmit(false);
        break;

      case 6:
        this.DebrisSubmit(false);
        break;

      case 7:
        this.PcrRoofData(false);
        break;

      case 8:
        this.PcrPoolData(false);
        break;

      case 9:
        this.PostUtilitiesSubmit(false);
        break;

      case 10:
        this.ApplianceSubmit(false);
        break;

      case 11:
        this.AddPCRDamage(false);
        break;

      case 12:
        this.PCRConveyancesave(false);
        break;

      default:
        break;
    }
    this.TabVal = TabNo;
  }
  PCRConveyancesave(arg0: boolean) {
    
  }
  AddPCRDamage(arg0: boolean) {
    
  }
  ApplianceSubmit(arg0: boolean) {
    
  }
  PostUtilitiesSubmit(arg0: boolean) {
    
  }
  PcrPoolData(arg0: boolean) {
    
  }
  PcrRoofData(arg0: boolean) {
    
  }
  DebrisSubmit(arg0: boolean) {
    
  }
  YardMaintananceSubmit(arg0: boolean) {
    
  }
  SubmitWinterization(arg0: boolean) {
    
  }
  SecuringSubmit(arg0: boolean) {
    
  }
  ViolationSubmit(arg0: boolean) {
    
  }
  FormButton1(arg0: boolean) {
    
  }
}
