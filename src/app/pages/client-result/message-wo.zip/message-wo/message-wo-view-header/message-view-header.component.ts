import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'message-wo-view-header',
  templateUrl: './message-view-header.component.html',
  styleUrls: ['../message-wo.component.scss']
})

export class MessageViewHeader {
  @Input() orderDetail: any;
  @Input() groupRoleID: number;
  @Input() workOrder: string;
  @Input() messageSearch: string;
  @Input() User_ImagePath: string;
  @Output() clickThread = new EventEmitter();
  @Output() changeSearch = new EventEmitter();
  @Input() userFullName: string;
  
  threadID: string;

  selectThread(thread) {
    this.clickThread.emit(thread);
  }

  onChangeEvent(e) {
    this.changeSearch.emit(e.target.value);
  }

}