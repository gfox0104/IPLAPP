export class ClientResultPIModel{
    PI_PkeyID: Number = 0;
    PI_WO_ID: Number = 0;
    PI_LockCode: String = "";
    PI_LockBox: String = "";
    PI_LotSize: Number=0;
    PI_ICC: boolean = false;
    PI_ICCDate:any;
    PI_DaysInDefault: String = "";
    PI_VPRRequired: boolean = false;
    PI_VPRField: boolean = false;
    PI_VPRExpDate:any;
    PI_InitDefaultDate:any;
    PI_PtvDate:any;
    PI_InitSecureDate:any;
    PI_DidRecDate:any;
    PI_RecurringDate:any;
    PI_OrCovDate:any;
    PI_ExtReqDate:any;
    PI_NewCovDate:any;
    PI_ExtReq: boolean = false;
    PI_Gason: boolean = false;
    PI_Wateron: boolean = false;
    PI_Elcton: boolean = false;
    PI_GasLR: String = "";
    PI_GasTS: String = "";
    PI_WaterLR: String = "";
    PI_WaterTS: String = "";
    PI_ElctLR: String = "";
    PI_ElctTS: String = "";
    PI_IsActive: boolean = true;
    Type:Number = 1;
    CRPI_BrokerInfo:string = '';
    CRPI_LoanNumber:string = '';
    CRPI_Mortgagor:string = '';

    CRPI_LoanType:string='';
    CRPI_Loan_Status:Number=0;
    CRPI_Property_Status:Number=0;
    CRPI_Property_Type:Number=0;
    CRPI_Occupanct_Status:Number=0;
    CRPI_Property_Alert:Number=0;

    CRPI_Property_Locked:string = '';
    CRPI_Front_Of_HouseImagePath:string = '';
    CRPI_Front_Of_HouseImageName:string = '';
    CRPI_GPS_Latitude:string=''
    CRPI_GPS_longitude:string=''

    PI_VPSCode:string="";
    PI_LockReason:Number=0;
    PI_Winterized:string="";
    PI_WinterizedDate:any;
    PI_ConveyanceCondition:string="";
    PI_Client:string="";
    PI_Customer:string="";

}
