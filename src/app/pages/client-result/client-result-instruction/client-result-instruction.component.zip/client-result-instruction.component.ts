import { Component, Injectable, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";

import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { FileInfo } from "@progress/kendo-angular-upload";
import { BindDataModel, TaskBidMasterModel } from "../client-result/client-result-model";
import {
  ClientResultInstructionModel,
  InstructionMasterDrDNameModel,
  InstructionMasterTaskTypeModel,
  InstructionMasterTaskModel,
  SigleEditBoxModel,
  InstructionAcessLogModel
} from "./client-result-instruction-model";
import { ClientResultInstructionServices } from "./client-result-instruction.service";
import * as $ from "jquery";
import { ClientResultServices } from '../client-result/client-result.service';
import { EncrDecrService } from "src/app/services/util/encr-decr.service";
import { BaseUrl } from "src/app/services/apis/rest-api";
import { ClientResultOldPhotoServices } from '../client-result-photo/client-result-photo-old.service';
import { AccessLog } from "./constants/fileds"

@Component({
  templateUrl: "./client-result-instruction.component.html",
 
})

export class ClientResultInstructionComponent implements OnInit {
  BindDataModelObj: BindDataModel = new BindDataModel();
  ClientResultInstructionModelObj: ClientResultInstructionModel = new ClientResultInstructionModel();
  InstructionMasterTaskTypeModelObj: InstructionMasterTaskTypeModel = new InstructionMasterTaskTypeModel();
  InstructionMasterDrDNameModelObj: InstructionMasterDrDNameModel = new InstructionMasterDrDNameModel();
  InstructionMasterTaskModelObj: InstructionMasterTaskModel = new InstructionMasterTaskModel();
  InstructionAcessLogModelObj: InstructionAcessLogModel = new InstructionAcessLogModel();
  InstructionDataArray = [];
  DetailsDataArray = [];
  InstDataArray = [];
  show = false;
  button = "Save"; // buttom loading..
  isLoading = false; // buttom loading..
  public contentx; // for common msg argument pass sathi
  MessageFlag: string; // custom msg sathi
  tempInstr_Task_Id = 0;
  SigleEditBoxModelObj: SigleEditBoxModel = new SigleEditBoxModel();
  private apiUrlGet = BaseUrl + "api/RESTIPLUPLOAD/PostUserDocumentUserImageBackground"; // get document 
  uploadSaveUrl = ""; // should represent an actual API endpoint
  uploadRemoveUrl = "removeUrl"; // should represent an actual API endpoint
  decuser: any;
  OfficeResulth: boolean = false;
  processorh: boolean = false;
  tabhide: boolean = false;
  myFiles: string[] = [];
  taskType = true;
  accessLog = AccessLog;
  isTaskInstruction = false;
  public taskList1: Array<string>;
  public taskList2: Array<string>;
  public defaultTaskItem: { Task_Name: string, Task_pkeyID: number } = { Task_Name: 'Select', Task_pkeyID: 0 };
  constructor(
    private xRouter: Router,
    private xClientResultInstructionServices: ClientResultInstructionServices,
    private modalService: NgbModal,
    private xRoute: ActivatedRoute,
    private xClientResultServices: ClientResultServices,
    private EncrDecr: EncrDecrService,
    private xClientResultOldPhotoServices: ClientResultOldPhotoServices

  ) {
    this.uploadSaveUrl = this.apiUrlGet;
    if (localStorage.getItem('usertemp_') != null) {
      var encuser = JSON.parse(localStorage.getItem('usertemp_'));
      var decval = this.EncrDecr.get('123456$#@$^@1ERF', (encuser));
      this.decuser = JSON.parse(decval);
     
      switch (this.decuser[0].GroupRoleId) {
        case 1:
          {
            this.OfficeResulth = false;
            this.processorh = false;
            this.tabhide = false;
            break;
          }
        case 2:
          {
            this.OfficeResulth = true;
            this.processorh = false;
            this.tabhide = true;
            break;
          }
        case 3:
          {
            this.OfficeResulth = false;
            this.processorh = false;
            this.tabhide = false;
            break;
          }
        case 4:
          {
            this.OfficeResulth = false;
            this.processorh = false;
            this.tabhide = false;
            break;
          }
      }
    }
  }

  ngOnInit() {

    this.getModelData();
  }
  //strip html
  instcom: any;
  removeTags(str) {
    debugger
    if ((str === null) || (str === ''))
      return false;
    else
      str = str.toString();
    return this.instcom = str.replace(/(<([^>]+)>)/ig, '');
  }
  countx = 0;
  onearray = [];
  twoarray = [];
  threearray = [];
  taskreq: String;
  ClientResultInstruCSumbit(content) {
    debugger
    this.contentx = content;
    this.countx = 0;
    let errCnt = 0;
    this.isLoading = true;
    this.button = "Processing";
    this.InstructionDataArray.forEach(item => {
      if(item.Instr_Task_pkeyId == 0)
      {
        errCnt++;
      }
      if(item.Instr_Task_Name == 0)
      {
        errCnt++;
      }
     
    })
    if(errCnt > 0)
    {
      this.isTaskInstruction = true;
      this.isLoading = false;
      this.button = "Save";
      this.MessageFlag = "Please fill all required feilds...!";
      this.commonMessage(this.contentx);
    }
    else{
      this.isTaskInstruction = false;
      for (let i = 0; i < this.InstructionDataArray.length; i++) {
        this.countx++;
        this.InstructionDataArray[i].Instr_Action = this.countx;
      }
      this.ClientResultInstructionModelObj.Instr_WO_Id = this.ModelObj.workOrder_ID;
      this.ClientResultInstructionModelObj.InstructionDataArray = this.InstructionDataArray.concat(
        this.DetailsDataArray,
        this.InstDataArray
      );
      this.SigleEditBoxModelObj.Inst_Ch_Wo_Id = this.ModelObj.workOrder_ID;
      this.SigleEditBoxModelObj.Instr_Comand_Mobile = this.removeTags(this.SigleEditBoxModelObj.Inst_Ch_Text);
      this.ClientResultInstructionModelObj.SingleEditBox = this.SigleEditBoxModelObj;
  
      this.xClientResultInstructionServices
        .InstructionPost(this.ClientResultInstructionModelObj)
        .subscribe(response => {
          if (response[0][0].Inst_Ch_pkeyId != 0) {
            debugger;
            this.SigleEditBoxModelObj.Inst_Ch_pkeyId = response[0][0].Inst_Ch_pkeyId;
          }
  
          this.isLoading = false;
          this.button = "Save";
          this.MessageFlag = "Data Saved...!";
          this.commonMessage(this.contentx);
          this.getdropdownTaskName();
          //this.GetInstuctionDataMain();
        });
    }
   
  }

  // common message modal popup
  commonMessage(content) {
    this.modalService
      .open(content, { size: "sm", ariaLabelledBy: "modal-basic-title" })
      .result.then(result => { }, reason => { });
  }
  /// end common model

  ModelObj: any;
  BindData: any;
  TaskBidMasterModelObj: TaskBidMasterModel = new TaskBidMasterModel();

  getModelData() {
    const workorder1 = this.xRoute.snapshot.params['workorder'];
    let workOrderID = this.EncrDecr.get('123456$#@$^@1ERF', atob(workorder1));
    const workorder = parseInt(workOrderID);
    this.TaskBidMasterModelObj.workOrder_ID = workorder;
    this.xClientResultServices
      .WorkorderViewClient(this.TaskBidMasterModelObj)
      .subscribe(response => {
        this.BindData = response[0][0];
        this.xClientResultServices.setPathParam(this.BindData);
        this.ModelObj = this.BindData;
        if (this.ModelObj == undefined) {
          this.xRouter.navigate(["/workorder"]);
        } else {
          this.BindDataModelObj.workOrderNumber = this.ModelObj.workOrderNumber;
          this.BindDataModelObj.address1 = this.ModelObj.address1;
          this.BindDataModelObj.Cont_Name = this.ModelObj.Cont_Name;
          this.BindDataModelObj.Cordinator_Name = this.ModelObj.Cordinator_Name;
          this.BindDataModelObj.Lock_Code = this.ModelObj.Lock_Code;
          this.BindDataModelObj.startDate = this.ModelObj.startDate;
          this.BindDataModelObj.Work_Type_Name = this.ModelObj.Work_Type_Name;
          this.BindDataModelObj.Lock_Location = this.ModelObj.Lock_Location;
          this.BindDataModelObj.Cust_Num_Number = this.ModelObj.Cust_Num_Number;
          this.BindDataModelObj.Key_Code = this.ModelObj.Key_Code;
          this.BindDataModelObj.Client_Company_Name = this.ModelObj.Client_Company_Name;
          this.BindDataModelObj.Gate_Code = this.ModelObj.Gate_Code;
          this.BindDataModelObj.BATF = this.ModelObj.BATF;
          this.BindDataModelObj.Lotsize = this.ModelObj.Lotsize;
          this.BindDataModelObj.rus_Name = this.ModelObj.rus_Name;
          this.BindDataModelObj.ClientMetaData = this.ModelObj.ClientMetaData;
          this.BindDataModelObj.Loan_Info = this.ModelObj.Loan_Info;
          this.BindDataModelObj.Broker_Info = this.ModelObj.Broker_Info;
          this.BindDataModelObj.Received_Date = this.ModelObj.Received_Date;
          this.BindDataModelObj.clientDueDate = this.ModelObj.clientDueDate;
          this.BindDataModelObj.Complete_Date = this.ModelObj.Complete_Date;
          this.BindDataModelObj.Cancel_Date = this.ModelObj.Cancel_Date;
          this.BindDataModelObj.IPLNO = this.ModelObj.IPLNO;
          //this.ClientResultPhotoModelobj.Client_Result_Photo_Wo_ID = this.ModelObj.workOrder_ID;
          this.BindData = this.ModelObj;
          //this.GetClientImages();
          this.getdropdowntask();
        }
      });
  }

  // get dropdown for type
  TypeNameArray: any;
  getdropdowntask() {
    this.xClientResultInstructionServices
      .InstructionTypeName(this.InstructionMasterTaskTypeModelObj)
      .subscribe(response => {
        this.TypeNameArray = response[0];
        this.getdropdownTaskTypeName();
      });
  }

  validate(evt) {
    var theEvent = evt || window.event;
    var key = theEvent.keyCode || theEvent.which;
    key = String.fromCharCode(key);
    var regex = /[0-9]|\./;
    if (!regex.test(key)) {
      theEvent.returnValue = false;
      if (theEvent.preventDefault) theEvent.preventDefault();
    }
  }
  //get dropdown for Type Name
  taskTypeNameArray: any;
  getdropdownTaskTypeName() {
    const workorder1 = this.xRoute.snapshot.params['workorder'];
    let workOrderID = this.EncrDecr.get('123456$#@$^@1ERF', atob(workorder1));
    const workorder = parseInt(workOrderID);
    this.InstructionMasterTaskModelObj.WorkOrderID = workorder;
    this.xClientResultInstructionServices
      .InstructionTaskTypeName(this.InstructionMasterTaskModelObj)
      .subscribe(response => {
        console.log('tasktype',response)
        this.taskTypeNameArray = response[0];
        this.CommonMethodCall_Array();
        this.getdropdownTaskName();
      });
  }

  getdescription(event){
    debugger

let task = this.taskTypeNameArray.find(item => item.Inst_Task_pkeyId == event.Instr_Task_pkeyId);

let data = {
Inst_Comand_Mobile_details: event.Inst_Comand_Mobile_details,
Instr_Action : event.Instr_Action,
Instr_Ch_pkeyId: event.Instr_Ch_pkeyId,
Instr_Client_Price:event.Instr_Client_Price,
Instr_Client_Total:event.Instr_Client_Total,
Instr_Contractor_Price:event.Instr_Contractor_Price,
Instr_Contractor_Total: event.Instr_Contractor_Total,
Instr_Details_Data: task.Inst_Task_Desc,
Instr_IsActive:event.Instr_IsActive,
Instr_IsDelete: event.Instr_IsDelete,
Instr_Price_Text: event.Instr_Price_Text,
Instr_Qty: event.Instr_Qty,
Instr_Qty_Text: event.Instr_Qty_Text,
Instr_Task_Comment: event.Instr_Task_Comment,
Instr_Task_Id: event.Instr_Task_Id,
Instr_Task_Name: event.Instr_Task_Name,
Instr_Task_pkeyId: event.Instr_Task_pkeyId,
Instr_Total_Text: event.Instr_Total_Text,
Instr_ValType: event.Instr_ValType,
Instr_WO_Id: event.Instr_WO_Id,
Instr_pkeyId: event.Instr_pkeyId,
UserID: event.UserID,
}

const index = this.InstDataArray.indexOf(event);
this.InstDataArray[index] = data;
//this.InstDataArray.push(data);

  }

  //get dropdown for Task Name
  TaskNameArray: any;
  valflag:any;
  getdropdownTaskName() {
    const workorder1 = this.xRoute.snapshot.params['workorder'];
    let workOrderID = this.EncrDecr.get('123456$#@$^@1ERF', atob(workorder1));
    const workorder = parseInt(workOrderID);
    this.InstructionMasterDrDNameModelObj.WorkOrderID = workorder;
    this.xClientResultInstructionServices
      .InstructionTaskNamedata(this.InstructionMasterDrDNameModelObj)
      .subscribe(response => {
        debugger
        console.log('task',response);
        this.valflag = response;
        this.TaskNameArray = response[0];
        this.GetInstuctionDataMain();
      });
  }

  taskTypeNameArrayNew = [];
  taskTypeNameArrayNewOne = [];
  taskTypeNameArrayNewTwo = [];
  Instr_ValType: Number = 0;

  AddMoreInstruction(arg) {
    console.log
    debugger
    this.Instr_ValType = arg;

    let data = {
      Instr_pkeyId: 0,
      Instr_Task_Id: 0,
      Instr_Task_pkeyId: 0,
      Instr_WO_Id: 0,
      Instr_Task_Name: 0,
      Instr_Qty: 1,
      Instr_Contractor_Price: 0,
      Instr_Client_Price: 0,
      Instr_Contractor_Total: 0,
      Instr_Client_Total: 0,
      Instr_Action: 0,
      Instr_IsActive: true,
      Instr_IsDelete: false,
      UserID: 0,
      Instr_Details_Data: "",
      Instr_ValType: this.Instr_ValType,
      Instr_Qty_Text: 0,
      Instr_Price_Text: 0,
      Instr_Total_Text: 0,
      Instr_Ch_pkeyId: 0,
      Instr_Task_Comment: "",
      Inst_Comand_Mobile_details: '',
      Instr_Other_Task_Name: '',
    };

    if (arg == 1) {
      this.InstructionDataArray.push(data);
    }
    if (arg == 2) {
      this.DetailsDataArray.push(data);
    }
    if (arg == 3) {
      this.InstDataArray.push(data);
    }
    //this.CommonMethodCall_Array();
  }

  CommonMethodCall_Array() {
    for (let i = 0; i < this.taskTypeNameArray.length; i++) {
      if (this.taskTypeNameArray[i].Inst_Task_Type_pkeyId == 1) {
        let taskTypedata = this.taskTypeNameArray[i];
        this.taskTypeNameArrayNew.push(taskTypedata);
      }
      if (this.taskTypeNameArray[i].Inst_Task_Type_pkeyId == 2) {
        let taskdetail = this.taskTypeNameArray[i];
        this.taskTypeNameArrayNewOne.push(taskdetail);
      }
      if (this.taskTypeNameArray[i].Inst_Task_Type_pkeyId == 3) {
        let taskinst = this.taskTypeNameArray[i];
        this.taskTypeNameArrayNewTwo.push(taskinst);
      }
    }
  }

  taskdetails = [];

  InstructionRemove(item, index) {
    debugger
   
    let promp = confirm("Are you Sure you want to  Delete this Record..?");
    if (promp) {
      if (item.Instr_pkeyId != "") {
        this.ClientResultInstructionModelObj.Instr_pkeyId = item.Instr_pkeyId;
        this.ClientResultInstructionModelObj.Instr_WO_Id = item.Instr_WO_Id;
        this.ClientResultInstructionModelObj.Type = 4;
        this.xClientResultInstructionServices
          .DeleteInstructionPost(this.ClientResultInstructionModelObj)
          .subscribe(response => {
            this.GetInstuctionDataMain();
          });
      }
      else {
        this.InstructionDataArray.splice(index, 1);
      }
    }
    if (this.InstructionDataArray.length == 0) {
      // this.AddMoreInstruction();
    }
  }
  DetailsRemove(index) {
    let promp = confirm("Are you Sure you want to  Delete this Record..?");
    if (promp) {
      this.DetailsDataArray.splice(index, 1);
    }
    if (this.DetailsDataArray.length == 0) {
      // this.AddMoreInstruction();
    }
  }
  InstRemove(item, index) {
    let promp = confirm("Are you Sure you want to  Delete this Record..?");
    if (promp) {
      if (item.Instr_pkeyId != "") {
        this.ClientResultInstructionModelObj.Instr_pkeyId = item.Instr_pkeyId;
        this.ClientResultInstructionModelObj.Instr_WO_Id = item.Instr_WO_Id;
        this.ClientResultInstructionModelObj.Type = 4;
        this.xClientResultInstructionServices
          .DeleteInstructionPost(this.ClientResultInstructionModelObj)
          .subscribe(response => {
            this.GetInstuctionDataMain()
          });
      }
      else {
        this.InstDataArray.splice(index, 1);
      }
    }
    if (this.InstDataArray.length == 0) {
      // this.AddMoreInstruction();
    }
  }

  arry = [];

  //get meta data task cha
 
  TaskNameMetaData_Method(item, ind) {
    debugger
  
    this.InstructionDataArray;
    if (this.valflag[1].Flag == 0) {
      for (let i = 0; i < this.InstructionDataArray.length; i++) {
        if (
          this.InstructionDataArray[i].Instr_Task_Name == item.Instr_Task_Name
        ) {
          for (let j = 0; j < this.TaskNameArray.length; j++) {
            if (this.TaskNameArray[j].Task_pkeyID == item.Instr_Task_Name) {
              this.InstructionDataArray[i].Instr_Contractor_Price = this.TaskNameArray[j].Task_Contractor_UnitPrice;
              this.InstructionDataArray[i].Instr_Client_Price = this.TaskNameArray[j].Task_Client_UnitPrice;
            }
          }
        }
      }
    }
    else if (this.valflag[1].Flag == 1) {
    
      for (let i = 0; i < this.InstructionDataArray.length; i++) {
        if (
          this.InstructionDataArray[i].Instr_Task_Name == item.Instr_Task_Name
        ) {
          for (let j = 0; j <   this.valflag[2].length; j++) {
            if (this.valflag[j].Task_pkeyID == item.Instr_Task_Name) {
              this.InstructionDataArray[i].Instr_Contractor_Price =   this.valflag[2][j].Task_Contractor_UnitPrice;
              this.InstructionDataArray[i].Instr_Client_Price =   this.valflag[2].Task_Client_UnitPrice;
            }
            else{
              for (let j = 0; j < this.TaskNameArray.length; j++) {
                if (this.TaskNameArray[j].Task_pkeyID == item.Instr_Task_Name) {
                  this.InstructionDataArray[i].Instr_Contractor_Price = this.TaskNameArray[j].Task_Contractor_UnitPrice;
                  this.InstructionDataArray[i].Instr_Client_Price = this.TaskNameArray[j].Task_Client_UnitPrice;
                }
              }
            }
          }
        }
      

      }
    }
  
  


    this.ClinetResultQtyInstrucation_Method();
  }
  backdropdown(item){

 let data = {
  Inst_Comand_Mobile_details: item.Inst_Comand_Mobile_details,
  Inst_Task_Name: item.Inst_Task_Name,
  Inst_Task_Type_pkeyId: item.Inst_Task_Type_pkeyId,
  Instr_Action: item.Instr_Action,
  Instr_Ch_pkeyId: item.Instr_Ch_pkeyId,
  Instr_Client_Price: item.Instr_Client_Price,
  Instr_Client_Total:item.Instr_Client_Total,
  Instr_Comand_Mobile: item.Instr_Comand_Mobile,
  Instr_Contractor_Price: item.Instr_Contractor_Price,
  Instr_Contractor_Total: item.Instr_Contractor_Total,
  Instr_Details_Data: item.Instr_Details_Data,
  Instr_IsActive: item.Instr_IsActive,
  Instr_IsDelete: item.Instr_IsDelete,
  Instr_Other_Task_Name: item.Instr_Other_Task_Name,
  Instr_Price_Text: item.Instr_Price_Text,
  Instr_Qty: item.Instr_Qty,
  Instr_Qty_Text: item.Instr_Qty_Text,
  Instr_Task_Comment:item.Instr_Task_Comment,
  Instr_Task_Id:item.Instr_Task_Id,
  Instr_Task_Name: "",
  Instr_Task_pkeyId: item.Instr_Task_pkeyId,
  Instr_Total_Text: item.Instr_Total_Text,
  Instr_ValType: item.Instr_ValType,
  Instr_WO_Id: item.Instr_WO_Id,
  Instr_pkeyId: item.Instr_pkeyId,
  TMF_Task_FileName: item.TMF_Task_FileName,
  TMF_Task_localPath: item.TMF_Task_localPath,
  Task_Name: item.Task_Name,
  }

  const index = this.InstructionDataArray.indexOf(item);
this.InstructionDataArray[index] = data;
  //this.InstructionDataArray.push(data);

  }
  // for table row up & down
  upmethod() {
    $(document).ready(function () {
      $(".up,.down").click(function () {
        var row = $(this).parents("tr:first");
        if ($(this).is(".up")) {
          row.insertBefore(row.prev());
        } else {
          row.insertAfter(row.next());
        }
      });
    });
  }

  // calculation here

  ClinetResultQtyInstrucation_Method() {
    for (let i = 0; i < this.InstructionDataArray.length; i++) {
      if (this.InstructionDataArray[i].Instr_Qty != "") {
        this.InstructionDataArray[i].Instr_Contractor_Total = this.InstructionDataArray[i].Instr_Contractor_Price * this.InstructionDataArray[i].Instr_Qty;
        this.InstructionDataArray[i].Instr_Client_Total = this.InstructionDataArray[i].Instr_Client_Price * this.InstructionDataArray[i].Instr_Qty;
      } else {
        this.InstructionDataArray[i].Instr_Qty = 1;
        this.InstructionDataArray[i].Instr_Contractor_Total = this.InstructionDataArray[i].Instr_Contractor_Price;
        this.InstructionDataArray[i].Instr_Client_Total = this.InstructionDataArray[i].Instr_Client_Price;
      }
    }
  }

  ClinetResultInstCont_Price_Method() {
    for (let i = 0; i < this.InstructionDataArray.length; i++) {
      if (this.InstructionDataArray[i].Instr_Contractor_Price != "") {
        this.InstructionDataArray[i].Instr_Contractor_Total = this.InstructionDataArray[i].Instr_Contractor_Price;
        if (this.InstructionDataArray[i].Instr_Qty != "") {
          this.InstructionDataArray[i].Instr_Contractor_Total = this.InstructionDataArray[i].Instr_Contractor_Price * this.InstructionDataArray[i].Instr_Qty;
        }
      } else {
      }
    }
  }

  ClinetResultInstClient_Price_Method() {
    for (let i = 0; i < this.InstructionDataArray.length; i++) {
      if (this.InstructionDataArray[i].Instr_Client_Price != "") {
        this.InstructionDataArray[i].Instr_Client_Total = this.InstructionDataArray[i].Instr_Client_Price;
        if (this.InstructionDataArray[i].Instr_Qty != "") {
          this.InstructionDataArray[i].Instr_Client_Total =
            this.InstructionDataArray[i].Instr_Client_Price *
            this.InstructionDataArray[i].Instr_Qty;
        }
      } else {
        //alert('plz enter number only');
      }
    }
  }

  // end calc


  // start calc New Details
  ClinetResultQtyInstrucationDetails_Method() {
    for (let i = 0; i < this.DetailsDataArray.length; i++) {
      if (this.DetailsDataArray[i].Instr_Qty_Text != "") {
        this.DetailsDataArray[i].Instr_Total_Text = this.DetailsDataArray[i].Instr_Price_Text * this.DetailsDataArray[i].Instr_Qty_Text;
      } else {
        this.DetailsDataArray[i].Instr_Total_Text = this.DetailsDataArray[i].Instr_Price_Text;
        this.DetailsDataArray[i].Instr_Qty_Text = 1;
      }
    }
  }

  ClinetResultInstContDetails_Price_Method() {
    for (let i = 0; i < this.DetailsDataArray.length; i++) {
      if (this.DetailsDataArray[i].Instr_Price_Text != "") {
        this.DetailsDataArray[i].Instr_Total_Text = this.DetailsDataArray[i].Instr_Price_Text;
        if (this.DetailsDataArray[i].Instr_Qty_Text != "") {
          this.DetailsDataArray[i].Instr_Total_Text = this.DetailsDataArray[i].Instr_Price_Text * this.DetailsDataArray[i].Instr_Qty_Text;
        }
      } else {
        //alert('plz enter number only');
      }
    }
  }
  // end calc New Details


  // START INSTU NEW
  ClinetResultQtyInstrucationISTRUNEW_Method() {
    for (let i = 0; i < this.InstDataArray.length; i++) {
      if (this.InstDataArray[i].Instr_Qty_Text != "") {
        this.InstDataArray[i].Instr_Total_Text = this.InstDataArray[i].Instr_Price_Text * this.InstDataArray[i].Instr_Qty_Text;
      } else {
        //alert('plz enter number only');

        // care fully
        this.InstDataArray[i].Instr_Total_Text = this.InstDataArray[i].Instr_Price_Text;
        this.InstDataArray[i].Instr_Qty_Text = 1;

      }
    }
  }

  ClinetResultPriceInstrucationISTRUNEW_Method() {

    for (let i = 0; i < this.InstDataArray.length; i++) {
      if (this.InstDataArray[i].Instr_Price_Text != "") {
        this.InstDataArray[i].Instr_Total_Text = this.InstDataArray[i].Instr_Price_Text;

        if (this.InstDataArray[i].Instr_Qty_Text != "") {
          this.InstDataArray[i].Instr_Total_Text = this.InstDataArray[i].Instr_Price_Text * this.InstDataArray[i].Instr_Qty_Text;
        }
      } else {
        //alert('plz enter number only');
      }
    }
  }



  // get main Instruction data
  documentdetailslst: any;
  GetInstuctionDataMain() {
    debugger;
    this.ClientResultInstructionModelObj.Instr_WO_Id = this.ModelObj.workOrder_ID;
    this.InstructionDataArray = [];
    this.DetailsDataArray = [];
    this.InstDataArray = [];
    this.xClientResultInstructionServices
      .InstructionGetMain(this.ClientResultInstructionModelObj)
      .subscribe(response => {
        debugger;
        console.log('instruction',response)
        this.documentdetailslst = response[2];
        if (response[0].length != 0) {
          this.documentdetailslst = response[2];
         
          for (let i = 0; i < response[0].length; i++) {
            if (response[0][i].Instr_ValType == 1) {
              const MainInst = response[0][i];
              this.InstructionDataArray.push(MainInst);
              this.TaskNameFilterMethod(response[0][i].Instr_Task_pkeyId);
            }

            if (response[0][i].Instr_ValType == 2) {
              const DetailsArr = response[0][i];
              this.DetailsDataArray.push(DetailsArr);
            }

            if (response[0][i].Instr_ValType == 3) {
              const InstArr = response[0][i];
              this.InstDataArray.push(InstArr);
            }
          }

        }
        if (response[1][0] && response[1][0].length != 0) {
          debugger;
          this.SigleEditBoxModelObj.Inst_Ch_pkeyId = response[1][0].Inst_Ch_pkeyId;
          this.SigleEditBoxModelObj.Inst_Ch_Wo_Id = response[1][0].Inst_Ch_Wo_Id;
          this.SigleEditBoxModelObj.Inst_Ch_Text = response[1][0].Inst_Ch_Text;
          this.SigleEditBoxModelObj.Inst_Ch_IsActive = response[1][0].Inst_Ch_IsActive;
          this.SigleEditBoxModelObj.Inst_Ch_Delete = response[1][0].Inst_Ch_Delete;
          this.SigleEditBoxModelObj.UserID = response[1][0].UserID;

        }
      });
    this.GetInstructionAcessdata();
  }

  // for access log 
  AccessLogData: any;
  ImportArr: any;
  GetInstructionAcessdata() {
    this.InstructionAcessLogModelObj.Alm_workOrder_ID = this.ModelObj.workOrder_ID;
    this.xClientResultInstructionServices.InsructionAcessLogData(this.InstructionAcessLogModelObj)
      .subscribe(response => {
        console.log('import data', response)
        this.AccessLogData = response[0];
        this.ImportArr = response[1][0];
      });
  }

  //document upload code 
  OpenDocumentUpload(contentpop) {
    this.commonPOPUPDocument(contentpop);
  }
  commonPOPUPDocument(content) {
    this.modalService
      .open(content, { size: "lg", ariaLabelledBy: "modal-basic-title" })
      .result.then(
        result => {
          this.GetInstuctionDataMain();
        },
        reason => {
          this.GetInstuctionDataMain();
        }
      );
  }
  public displayErrorDocument(e: ErrorEvent) {
  }

  public displaySuccessDocument(e) {
    if (e.operation == "upload") {
      this.processDocument(e.files[0].rawFile);
    } else {
      alert("remove img called");
    }
  }


  //document upload 

  processDocument(documentInput) {
    if (true) {
      debugger;
      this.BindDataModelObj.Common_pkeyID = this.ModelObj.workOrder_ID;
      this.BindDataModelObj.Client_Result_Photo_Ch_ID = this.SigleEditBoxModelObj.Inst_Ch_pkeyId;
      this.BindDataModelObj.Client_Result_Photo_ID = this.ModelObj.Inst_Doc_PkeyID;
      this.BindDataModelObj.Client_PageCalled = 1;
      this.BindDataModelObj.documentx = documentInput;
      this.BindDataModelObj.Client_Result_Photo_FileName = documentInput.name;
      this.BindDataModelObj.Type = 1;
      this.xClientResultOldPhotoServices
        .CommonDocumentsUpdate(this.BindDataModelObj)
        .then((res) => {
          res.subscribe(() => { });
          this.GetInstuctionDataMain();
        });
    }
  }
  //remove file
  removeinstructionfile(item) {
    let Cnfm = confirm("Are you Sure you want to  Delete this Record..?");
    if (Cnfm) {
      this.InstructionAcessLogModelObj.Inst_Doc_PkeyID = item.Inst_Doc_PkeyID;
      this.xClientResultInstructionServices.delinstructionfile(this.InstructionAcessLogModelObj)
        .subscribe(res => {
          console.log("del", res);
          this.getModelData();
        });
    }
  }

  //instruction comment push task comment
  taskcommentdata(item) {
    this.removeTags(item.Instr_Details_Data);
    debugger
    let taskcomm = this.instcom
    console.log('chk', taskcomm);
    let data = {
      Instr_pkeyId: 0,
      Instr_Task_Id: 0,
      Instr_Task_pkeyId: 0,
      Instr_WO_Id: 0,
      Instr_Task_Name: 0,
      Instr_Qty: 1,
      Instr_Contractor_Price: 0,
      Instr_Client_Price: 0,
      Instr_Contractor_Total: 0,
      Instr_Client_Total: 0,
      Instr_Action: 0,
      Instr_IsActive: true,
      Instr_IsDelete: false,
      UserID: 0,
      Instr_Details_Data: "",
      Instr_ValType: this.Instr_ValType,
      Instr_Qty_Text: 0,
      Instr_Price_Text: 0,
      Instr_Total_Text: 0,
      Instr_Ch_pkeyId: 0,
      Instr_Task_Comment: taskcomm,

    };
    this.InstructionDataArray.push(data);


  }
  TaskNameList:any;
  TaskNameListone:any;
  TaskNameFilterMethod(val){
    console.log('this.TaskNameArray',this.TaskNameArray)
    if (val == 1 || val == 3) {
      let storeId = 1;
      this.TaskNameList = this.TaskNameArray.filter((item) => item.Task_Type === storeId);
      var data = {
        Task_pkeyID:"other",
        Task_Name:"Custom"
      }
      this.TaskNameList.push(data);
      console.log('checktask',this.TaskNameList)
      this.taskList1 = this.TaskNameList;
    }
    else
    {
      let storeId = 2;
      this.TaskNameListone = this.TaskNameArray.filter((item) => item.Task_Type === storeId);
      var data = {
        Task_pkeyID:"other",
        Task_Name:"Custom"
      }
      this.TaskNameListone.push(data);
      this.taskList2 = this.TaskNameListone;
    }
  }
  TaskList1Filter(value) {
    debugger;
    if (value!='') {
      var filteredcustomer = this.TaskNameList.filter(function (el) {
        return el.Task_Name != null;
      });
      this.taskList1 = filteredcustomer.filter((s) => s.Task_Name.toLowerCase().indexOf(value.toLowerCase()) !== -1);
    }
   else{
    this.taskList1 = this.TaskNameList.slice();
   }
  }
  TaskList2Filter(value) {
    debugger;
    if (value!='') {
      var filteredcustomer = this.TaskNameListone.filter(function (el) {
        return el.Task_Name != null;
      });
      this.taskList1 = filteredcustomer.filter((s) => s.Task_Name.toLowerCase().indexOf(value.toLowerCase()) !== -1);
    }
   else{
    this.taskList1 = this.TaskNameListone.slice();
   }
  }

}
