// import { CommonModule } from "@angular/common";
// import { NgModule } from "@angular/core";
// import { FormsModule, ReactiveFormsModule } from "@angular/forms";
// import { RouterModule } from "@angular/router";
// import { HttpClientModule } from "@angular/common/http";
// import { NgbModule } from "@ng-bootstrap/ng-bootstrap";

// import { ClientResultInstructionComponent } from "./ClientResultInstructionComponent";
// import { ClientResultInstructionServices } from "./ClientResultInstructionServices";
// import {CommonDirectiveModule} from '../../AppDirectives/DirectiveModule';


// const ClientResultInstructionRouts = [
//   { path: "clientresultinstruction", component: ClientResultInstructionComponent }
// ]

// @NgModule({
//   declarations: [ClientResultInstructionComponent],
//   imports: [
//     RouterModule.forChild(ClientResultInstructionRouts),
//     CommonModule,
//     FormsModule,
//     ReactiveFormsModule,
//     CommonDirectiveModule,
//     NgbModule,

//   ],
//   providers: [ClientResultInstructionServices],
//   bootstrap: [ClientResultInstructionComponent]
// })

// export class ClientResultInstructionModule {}
